# Serial_Communication_Model

C++ Serial Communication model （串口通信模块）

## Flow Chart

![](img/serial_communication.jpg)

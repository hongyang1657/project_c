/*-
 * Copyright (c) 2007, 2008, Andrea Bittau <a.bittau@cs.ucl.ac.uk>
 *
 * pack structures
 *
 */

#ifndef __AIRCRACK_NG_OSDEP_PACKED_H__
#define __AIRCRACK_NG_OSDEP_PACKED_H__

#ifndef __packed
#define __packed __attribute__ ((__packed__))
#endif /* __packed */

#ifndef __aligned
#define __aligned(n)
#endif

#endif /* __AIRCRACK_NG_OSEDEP_PACKED_H__ */

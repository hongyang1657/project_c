export PATH=$PATH:/opt/toolchain-arm_cortex-a7+neon_gcc-5.3.0_glibc-2.22_eabi/bin
